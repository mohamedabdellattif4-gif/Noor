package com.noor.core.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Consistent spacing scale used instead of scattered layout values. */
@Immutable
data class NoorSpacing(
    val none: Dp = 0.dp,
    val extraSmall: Dp = 4.dp,
    val small: Dp = 8.dp,
    val medium: Dp = 16.dp,
    val large: Dp = 24.dp,
    val extraLarge: Dp = 32.dp,
    val huge: Dp = 48.dp,
)

internal val DefaultNoorSpacing = NoorSpacing()
internal val LocalNoorSpacing = staticCompositionLocalOf { DefaultNoorSpacing }
